<a href="https://imgbb.com/"><img src="https://i.ibb.co/NNddWmz/Frame-1.png" alt="Frame-1" border="0"></a>
A mobile application supporting women safety with a fast functioning system.
Alerts can be sent to authorities and required persons with a single tap.

# EMERGENCY APP FOR WOMEN SAFETY BY TECH PANACEA

Mobile Application Including SoS and many other safety features.
Android Application for women's safety and well being. Application comprises many cool features like safety track for journey and instant emergency SOS button under attacks.No need of internet connection. You can send alert signal to all your emergency contacts in an easy trigger.

Highlight : You dont need to open application for triggering. just press volume button 2 times. It will send ur location details to your emergency conatcs and police if u want to



